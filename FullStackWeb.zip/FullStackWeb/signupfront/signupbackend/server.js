const express = require("express");
const app = express();
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const routesUrls = require("./routes/routes")
const cors =  require("cors")

dotenv.config();


mongoose.connect(process.env.DATABASE_ACCESS, () => console.log("Data Base connected Sucessfully..."))

//Pass in the boddy pater the income that we gonna request
app.use(express.json())
app.use(cors())

app.use("/app",  routesUrls) //To connect the rountes to catch the response.
//routesUrls .js will be appended to base path ("/app") if the user no esta
//Logueado entonces el url es www.mywebsite.com/app/signup
//Si esta logueado entonces es.
//www.mywebsite.com/app/signin
app.listen(4000, () => console.log("Server is up and running"))
