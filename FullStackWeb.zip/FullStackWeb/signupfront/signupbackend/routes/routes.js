//This file is responsable for routing the reques that comes from the server

const express = require("express");
const router = express.Router();
const signUpTemplateCopy =  require("../models/SignUpModels.js")
const path = require("path");







router.post("/signup", (request, response) => {
    const signUpUser  =  new signUpTemplateCopy({
        fullName: request.body.fullName,
        userName: request.body.userName,
        email: request.body.email,
        password:  request.body.password
    })
    signUpUser.save()
    .then(data =>  {
        response.json(data)
    })
    .catch(error => {
        response.json(error)
    })
})


router.get("/", (request, response) => {
    /*response.send("Express is working");*/
    /*response.sendFile(path.join(__dirname, "../../"));*/
    response.sendFile(path.join(__dirname, "../../index.html"));

});

 /*console.log(__dirname);*/

//router.get("/sigin") //An example of how many urls the webpage will have!
module.exports = router
